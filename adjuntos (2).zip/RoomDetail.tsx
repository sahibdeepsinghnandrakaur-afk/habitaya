
import React, { useState, useRef, useEffect } from 'react';
import { Room, ChatMessage, Review } from '../types';
import { assistant } from '../services/geminiService';
import { PaymentModal } from './PaymentModal';

interface RoomDetailProps {
  room: Room;
  onClose: () => void;
  onAddReview: (roomId: string, review: Review) => void;
}

export const RoomDetail: React.FC<RoomDetailProps> = ({ room, onClose, onAddReview }) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '', userName: '' });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isChatOpen && messages.length === 0) {
      setMessages([{
        role: 'model',
        text: `¡Hola! Soy ${room.ownerName}, el propietario. He visto que te interesa mi habitación. ¿Quieres venir a verla o prefieres reservarla directamente por aquí?`,
        timestamp: new Date()
      }]);
    }
  }, [isChatOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const reply = await assistant.sendHostMessage(input, messages, room);
    setMessages(prev => [...prev, { role: 'model', text: reply, timestamp: new Date() }]);
    setIsLoading(false);
  };

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.comment || !newReview.userName) return;

    const review: Review = {
      id: Date.now().toString(),
      userName: newReview.userName,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split('T')[0]
    };

    onAddReview(room.id, review);
    setNewReview({ rating: 5, comment: '', userName: '' });
  };

  const avgRating = room.reviews.length > 0 
    ? (room.reviews.reduce((acc, r) => acc + r.rating, 0) / room.reviews.length).toFixed(1)
    : "Sin valoraciones";

  return (
    <div className="animate-in fade-in slide-in-from-top-4 duration-500 bg-white min-h-screen">
      <div className="max-w-screen-xl mx-auto px-6 py-6">
        <button onClick={onClose} className="group flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-bold transition-colors mb-4">
          <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
          </svg>
          Volver al listado
        </button>
        <h1 className="text-4xl font-black text-slate-900 leading-tight mb-2">{room.title}</h1>
        <div className="flex items-center gap-4 text-slate-500 text-sm font-medium">
          <span className="flex items-center gap-1">
            <svg className="w-4 h-4 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            </svg>
            {room.location}
          </span>
          <span className="w-1 h-1 rounded-full bg-slate-300"></span>
          <span className="flex items-center gap-1 font-bold text-slate-700">
            <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            {avgRating} {room.reviews.length > 0 && `(${room.reviews.length} reseñas)`}
          </span>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 grid grid-cols-4 gap-4 mb-10 h-[400px] md:h-[500px]">
        <div className="col-span-4 md:col-span-3 rounded-2xl overflow-hidden shadow-sm">
          <img src={room.image} className="w-full h-full object-cover" alt={room.title} />
        </div>
        <div className="hidden md:flex flex-col gap-4">
          <div className="flex-1 rounded-2xl overflow-hidden shadow-sm">
             <img src="https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover" alt="Detalle" />
          </div>
          <div className="flex-1 rounded-2xl overflow-hidden bg-indigo-50 flex items-center justify-center border border-indigo-100 cursor-pointer">
             <span className="text-indigo-600 font-bold text-sm">+ Ver todas</span>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-12 pb-24">
        <div className="lg:col-span-2 space-y-12">
          <section className="pb-8 border-b border-slate-100">
            <h2 className="text-2xl font-black text-slate-900 mb-6">Descripción</h2>
            <p className="text-slate-600 leading-relaxed text-lg">{room.description}</p>
          </section>

          <section className="space-y-8">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-black text-slate-900">Reseñas de la comunidad</h2>
              <div className="flex items-center gap-1 bg-yellow-50 px-3 py-1 rounded-full border border-yellow-100">
                <svg className="w-5 h-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span className="font-black text-yellow-700">{avgRating}</span>
              </div>
            </div>
            <div className="space-y-6">
              {room.reviews.map(review => (
                <div key={review.id} className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="flex justify-between items-start mb-3">
                    <p className="font-bold text-slate-900">{review.userName}</p>
                    <p className="text-xs text-slate-400">{review.date}</p>
                  </div>
                  <p className="text-slate-600 italic text-sm">"{review.comment}"</p>
                </div>
              ))}
            </div>
            <form onSubmit={submitReview} className="p-8 rounded-3xl bg-indigo-50/50 border border-indigo-100 space-y-4">
              <h3 className="font-black text-indigo-900">Deja tu opinión</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input required type="text" placeholder="Tu nombre" className="px-4 py-3 rounded-xl border border-white outline-none" value={newReview.userName} onChange={e => setNewReview({ ...newReview, userName: e.target.value })} />
                <select className="px-4 py-3 rounded-xl border border-white outline-none" value={newReview.rating} onChange={e => setNewReview({ ...newReview, rating: parseInt(e.target.value) })}>
                   <option value="5">5 estrellas</option>
                   <option value="4">4 estrellas</option>
                   <option value="3">3 estrellas</option>
                </select>
              </div>
              <textarea required placeholder="Cuéntanos tu experiencia..." rows={3} className="w-full px-4 py-3 rounded-xl border border-white outline-none resize-none" value={newReview.comment} onChange={e => setNewReview({ ...newReview, comment: e.target.value })} />
              <button type="submit" className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-700 shadow-xl transition-all">Publicar Reseña</button>
            </form>
          </section>
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-28 space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-8 overflow-hidden">
              <div className="flex justify-between items-baseline mb-8">
                <div>
                  <span className="text-4xl font-black text-slate-900">${room.price}</span>
                  <span className="text-slate-400 font-bold ml-1">/mes</span>
                </div>
              </div>
              <div className="space-y-4 mb-8">
                <button 
                  onClick={() => setIsPaymentOpen(true)}
                  className="w-full flex items-center justify-center gap-3 bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-2xl font-black transition-all shadow-lg shadow-indigo-100"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                  Reservar Ahora
                </button>
                <a href={`tel:+34${room.phone.replace(/\s+/g, '')}`} className="w-full flex items-center justify-center gap-3 bg-slate-100 hover:bg-slate-200 text-slate-700 py-4 rounded-2xl font-black transition-all">
                  Llamar a {room.ownerName}
                </a>
                <button onClick={() => setIsChatOpen(true)} className="w-full flex items-center justify-center gap-3 border border-indigo-200 text-indigo-600 py-4 rounded-2xl font-black hover:bg-indigo-50 transition-all">
                  Enviar mensaje
                </button>
              </div>
              <div className="flex items-center gap-2 justify-center text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
                Pago seguro garantizado
              </div>
            </div>
          </div>
        </div>
      </div>

      {isChatOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-xl h-[600px] rounded-3xl shadow-2xl flex flex-col overflow-hidden">
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-indigo-600 text-white">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold">{room.ownerName.charAt(0)}</div>
                  <h3 className="font-black">Mensaje para {room.ownerName}</h3>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="hover:bg-white/10 p-2 rounded-full transition-colors">
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-sm shadow-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'}`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-100 flex gap-1">
                      <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:-.3s]"></div>
                      <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:-.5s]"></div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={handleSend} className="p-6 bg-white border-t border-slate-100 flex gap-4">
                <input type="text" placeholder="Escribe tu mensaje..." className="flex-1 bg-slate-50 border border-slate-100 px-6 py-4 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-indigo-500/20" value={input} onChange={(e) => setInput(e.target.value)} />
                <button type="submit" disabled={isLoading} className="bg-indigo-600 text-white p-4 rounded-2xl hover:bg-indigo-700 shadow-lg">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </button>
              </form>
           </div>
        </div>
      )}

      {isPaymentOpen && <PaymentModal room={room} onClose={() => setIsPaymentOpen(false)} />}
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { Room, Review, PlatformReview } from './types';
import { RoomCard } from './components/RoomCard';
import { RoomForm } from './components/RoomForm';
import { RoomDetail } from './components/RoomDetail';
import { ChatWidget } from './components/ChatWidget';
import { LoginModal } from './components/LoginModal';

const INITIAL_ROOMS: Room[] = [
  {
    id: '1',
    title: 'Estudio moderno en el corazón de Madrid',
    description: 'Habitación espaciosa y recién reformada con cama doble de alta gama, escritorio ergonómico para teletrabajo y balcón privado con vistas a la calle principal.',
    price: 450,
    location: 'Madrid, Centro-Sol',
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=1200',
    amenities: ['Wifi 600Mb', 'Balcón', 'Escritorio', 'Cama Doble', 'Limpieza semanal'],
    ownerName: 'Carlos Ruiz',
    phone: '612 345 678',
    reviews: [
      { id: 'r1', userName: 'Lucía M.', rating: 5, comment: 'Increíble estancia, Carlos es muy atento.', date: '2024-03-15' }
    ]
  },
  {
    id: '2',
    title: 'Suite minimalista en Gràcia con baño propio',
    description: 'Ambiente extremadamente silencioso y acogedor, perfecto para profesionales que buscan tranquilidad.',
    price: 520,
    location: 'Barcelona, Barrio de Gràcia',
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1200',
    amenities: ['Wifi', 'Gastos incluidos', 'Aire acondicionado', 'Baño privado'],
    ownerName: 'Elena Martínez',
    phone: '623 456 789',
    reviews: []
  }
];

const INITIAL_PLATFORM_REVIEWS: PlatformReview[] = [
  {
    id: 'p1',
    userName: 'Marta Jiménez',
    userRole: 'Inquilina',
    rating: 5,
    comment: 'Encontré habitación en 2 días. El sistema de pago es súper seguro.',
    avatar: 'https://i.pravatar.cc/150?u=marta'
  }
];

const App: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>(INITIAL_ROOMS);
  const [platformReviews, setPlatformReviews] = useState<PlatformReview[]>(INITIAL_PLATFORM_REVIEWS);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isPlatformReviewOpen, setIsPlatformReviewOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [user, setUser] = useState<{name: string} | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  const [newPReview, setNewPReview] = useState({ userName: '', userRole: 'Inquilino', rating: 5, comment: '' });

  const handleAddRoom = (newRoom: Room) => {
    setRooms(prev => [newRoom, ...prev]);
  };

  const handleAddRoomReview = (roomId: string, review: Review) => {
    setRooms(prev => prev.map(room => 
      room.id === roomId ? { ...room, reviews: [review, ...room.reviews] } : room
    ));
    if (selectedRoom && selectedRoom.id === roomId) {
      setSelectedRoom(prev => prev ? { ...prev, reviews: [review, ...prev.reviews] } : null);
    }
  };

  const handleAddPlatformReview = (e: React.FormEvent) => {
    e.preventDefault();
    const review: PlatformReview = {
      id: Date.now().toString(),
      userName: newPReview.userName,
      userRole: newPReview.userRole,
      rating: newPReview.rating,
      comment: newPReview.comment,
      avatar: `https://i.pravatar.cc/150?u=${newPReview.userName}`
    };
    setPlatformReviews(prev => [review, ...prev]);
    setIsPlatformReviewOpen(false);
    setNewPReview({ userName: '', userRole: 'Inquilino', rating: 5, comment: '' });
  };

  useEffect(() => {
    if (selectedRoom) window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedRoom]);

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-indigo-100 selection:text-indigo-900">
      <nav className="bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm">
        <div className="max-w-screen-2xl mx-auto px-6 h-20 flex justify-between items-center">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setSelectedRoom(null)}>
              <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tighter">roomy.es</span>
            </div>
          </div>
          <div className="flex items-center gap-6">
            {!user ? (
              <button 
                onClick={() => setIsLoginOpen(true)}
                className="text-sm font-bold text-slate-600 hover:text-indigo-600 transition-colors"
              >
                Iniciar sesión
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">Hola,</span>
                <span className="text-sm font-bold text-slate-800">{user.name}</span>
              </div>
            )}
            <button
              onClick={() => setIsFormOpen(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-full font-bold shadow-md transition-all text-sm"
            >
              Anuncia tu habitación
            </button>
          </div>
        </div>
      </nav>

      {!selectedRoom ? (
        <>
          <header className="bg-slate-50 border-b border-slate-100 overflow-hidden">
            <div className="max-w-screen-2xl mx-auto px-6 py-16 md:py-24 grid md:grid-cols-2 items-center gap-12">
              <div className="max-w-xl text-center md:text-left">
                <h1 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 leading-[1.1]">
                  Reserva tu habitación con <span className="text-indigo-600">pago seguro</span> garantizado.
                </h1>
                <p className="text-lg text-slate-600 mb-10 leading-relaxed">
                  Busca entre miles de habitaciones verificadas en toda España. Realiza el pago del primer mes de forma segura a través de nuestra plataforma.
                </p>
                <div className="flex justify-center md:justify-start gap-4">
                   <div className="flex -space-x-3 overflow-hidden">
                      {platformReviews.slice(0, 3).map(r => (
                        <img key={r.id} className="inline-block h-10 w-10 rounded-full ring-2 ring-white shadow-sm" src={r.avatar} alt={r.userName} />
                      ))}
                   </div>
                   <div className="text-sm font-medium text-slate-500">
                      <p className="text-slate-900 font-bold">Reseñas reales verificadas</p>
                      <p>Valoración de 4.9/5</p>
                   </div>
                </div>
              </div>
              <div className="relative hidden md:block">
                <img 
                  src="https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&q=80&w=1000" 
                  className="rounded-3xl shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500"
                  alt="Habitación luminosa"
                />
              </div>
            </div>
          </header>

          <main className="max-w-screen-2xl mx-auto px-6 py-16">
            <h2 className="text-3xl font-black text-slate-900 mb-12">Habitaciones destacadas hoy</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-24">
              {rooms.map((room) => (
                <RoomCard key={room.id} room={room} onViewDetail={(r) => setSelectedRoom(r)} />
              ))}
            </div>

            <section className="bg-indigo-50/50 -mx-6 px-6 py-20 rounded-[3rem]">
               <div className="max-w-4xl mx-auto text-center mb-16">
                  <h2 className="text-4xl font-black text-slate-900 mb-4">Lo que dicen de Roomy</h2>
                  <button onClick={() => setIsPlatformReviewOpen(true)} className="mt-8 text-indigo-600 font-bold hover:bg-indigo-100 px-6 py-2 rounded-full border border-indigo-200 transition-all">
                    Dejar mi opinión sobre la web
                  </button>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {platformReviews.map((review) => (
                    <div key={review.id} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col h-full">
                       <p className="text-slate-700 italic flex-1 mb-6">"{review.comment}"</p>
                       <div className="flex items-center gap-4">
                          <img src={review.avatar} className="w-12 h-12 rounded-full" alt={review.userName} />
                          <div>
                            <p className="font-bold text-slate-900">{review.userName}</p>
                            <p className="text-xs text-slate-400 font-bold uppercase">{review.userRole}</p>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
            </section>
          </main>
        </>
      ) : (
        <RoomDetail room={selectedRoom} onClose={() => setSelectedRoom(null)} onAddReview={handleAddRoomReview} />
      )}

      <footer className="bg-slate-900 text-white pt-20 pb-10">
        <div className="max-w-screen-2xl mx-auto px-6 text-center text-xs text-slate-500">
          <p>© 2024 Roomy Real Estate S.L. Tu comunidad de confianza para alquilar.</p>
        </div>
      </footer>

      {isFormOpen && <RoomForm onAddRoom={handleAddRoom} onClose={() => setIsFormOpen(false)} />}
      {isLoginOpen && <LoginModal onClose={() => setIsLoginOpen(false)} onLogin={(name) => { setUser({name}); setIsLoginOpen(false); }} />}
      {isPlatformReviewOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl">
            <h2 className="text-2xl font-black text-slate-900 mb-6 text-center">Cuéntanos tu experiencia</h2>
            <form onSubmit={handleAddPlatformReview} className="space-y-4">
               <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Nombre</label>
                  <input required type="text" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none" value={newPReview.userName} onChange={e => setNewPReview({...newPReview, userName: e.target.value})} />
               </div>
               <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Tu perfil</label>
                  <select className="w-full px-4 py-2 rounded-xl border border-slate-200" value={newPReview.userRole} onChange={e => setNewPReview({...newPReview, userRole: e.target.value})}>
                    <option>Inquilino</option>
                    <option>Propietario</option>
                    <option>Estudiante</option>
                  </select>
               </div>
               <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Opinión</label>
                  <textarea required rows={3} className="w-full px-4 py-2 rounded-xl border border-slate-200 resize-none" value={newPReview.comment} onChange={e => setNewPReview({...newPReview, comment: e.target.value})} />
               </div>
               <div className="flex gap-3 pt-4">
                  <button type="button" onClick={() => setIsPlatformReviewOpen(false)} className="flex-1 px-4 py-3 rounded-xl font-bold text-slate-500 hover:bg-slate-50">Cancelar</button>
                  <button type="submit" className="flex-1 px-4 py-3 rounded-xl font-bold bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg">Enviar opinión</button>
               </div>
            </form>
          </div>
        </div>
      )}
      <ChatWidget />
    </div>
  );
};

export default App;
